# Spring Boot MongoDB CRUD example - Restful CRUD API

For more detail, please visit:
> [Spring Boot with MongoDB CRUD example using Spring Data](https://bezkoder.com/spring-boot-mongodb-crud/)

## Run Spring Boot application
```
mvn spring-boot:run
```
