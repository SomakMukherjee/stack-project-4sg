import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class IntercomponentService {

  private messageSource = new BehaviorSubject(' Not Logged In ');
  private userId = new BehaviorSubject('');
  private companyId = new BehaviorSubject('');
  private stockExchangeId = new BehaviorSubject('');
  private ipoId = new BehaviorSubject('');

  currentMessage = this.messageSource.asObservable();
  currentId = this.userId.asObservable();
  currentCompanyId = this.companyId.asObservable();
  currentStockExchangeId = this.stockExchangeId.asObservable();
  currentIpoId = this.ipoId.asObservable();

  constructor() { }

  changeMessage(message: string) {
      this.messageSource.next(message);
    }

  changeId(id: string){
    this.userId.next(id);
  }

  changeCompanyId(id: string){
      this.companyId.next(id);
    }

   changeStockExchangeId(id: string){
    this.stockExchangeId.next(id);
   }

   changeIpoId(id: string){
       this.ipoId.next(id);
      }
}
