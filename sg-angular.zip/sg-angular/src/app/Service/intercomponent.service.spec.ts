import { TestBed } from '@angular/core/testing';

import { IntercomponentService } from './intercomponent.service';

describe('IntercomponentService', () => {
  let service: IntercomponentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IntercomponentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
