import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { delay } from "rxjs/operators";
import { Company, StockExchange } from '../Models/Company';

@Injectable({
  providedIn: 'root'
})
export class PageService {

  constructor(private http: HttpClient) { }
  baseUrl = '//localhost:8088';
  loginUrl = '/service-login';
  companyUrl = '/service-company';
  getUsers(): Observable<any>{
    return this.http.get(this.baseUrl+this.loginUrl+"/getAll");
  }
  addUser(user: Object): Observable<any>{
      return this.http.post<any>(this.baseUrl+this.loginUrl+"/add",user);
    }

  uploadExcelJson(jsonFile:string): Observable<any>{
      return this.http.post<any>(this.baseUrl+"/service-excel/importExcel",jsonFile);
    }

  login(user:Object): Observable<any>{
    return this.http.post(this.baseUrl+this.loginUrl+"/login",user);
  }

  getCompanies():Observable<any>{
    return this.http.get(this.baseUrl+this.companyUrl+"/companies");
  }

  addCompany(company: Object): Observable<any>{
    return this.http.post<any>(this.baseUrl+this.companyUrl+"/companies/add",company);
  }

  getCompanyById(id: String):Observable<any>{
    return this.http.get(this.baseUrl+this.companyUrl+"/companies/id/"+id);
  }

  updateCompany(company: Company):Observable<any>{
    return this.http.put<any>(this.baseUrl+this.companyUrl+"/companies/update/",company);
  }

  getSectors(): Observable<any>{
    return this.http.get(this.baseUrl+this.companyUrl+"/sectors");
  }

  getStockExchanges(): Observable<any>{
    return this.http.get(this.baseUrl+this.companyUrl+"/stockExchanges");
  }

  getStockExchangeById(id: string): Observable<any>{
      return this.http.get(this.baseUrl+this.companyUrl+"/stockExchanges/"+id);
    }

  addStockExchange(se:string,cc:string,cn:string): Observable<any>{
      return this.http.post<any>(this.baseUrl+this.companyUrl+"/companies/stockExchange/add/"+cn+"/"+se+"/"+cc,null);
    }

  getCompanyCodes(se: string): Observable<any>{
      return this.http.get(this.baseUrl+this.companyUrl+"/stockCodes/"+se);
    }

  deleteStockExchangeFromCompany(cn:string, se:string): Observable<any>{
      return this.http.post<any>(this.baseUrl+this.companyUrl+"/companies/stockExchange/delete/"+cn+"/"+se,null);
  }

  deleteCompany(companyId: string): Observable<any>{
      return this.http.delete(this.baseUrl+this.companyUrl+"/companies/delete/"+companyId);
  }

  createNewStockExchange(se: StockExchange): Observable<any>{
    return this.http.post<any>(this.baseUrl+this.companyUrl+"/stockExchanges/add",se)
  }

  updateStockExchange(se: StockExchange): Observable<any>{
    return this.http.post<any>(this.baseUrl+this.companyUrl+"/stockExchanges/update",se);
  }

  getIpos(companyName: string): Observable<any>{
    return this.http.get(this.baseUrl+this.companyUrl+"/ipos/"+companyName);
  }

  addIpo(ipo: Object): Observable<any>{
      return this.http.post<any>(this.baseUrl+this.companyUrl+"/ipos/add",ipo)
    }
}
