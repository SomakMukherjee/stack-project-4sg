import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/Forms';
import { Routes, RouterModule } from '@angular/router';

import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { LoginComponent } from './Components/login/login.component';
import { AppRoutingModule } from './app-routing.module';
import { TempComponent } from './Components/temp/temp.component';
import { TopBarComponent } from './Components/top-bar/top-bar.component';
import { Temp2Component } from './Components/temp2/temp2.component';
import { ExcelImportComponent } from './Components/excel-import/excel-import.component';
import { ManageCompaniesComponent } from './Components/manage-companies/manage-companies.component';
import { CompaniesAdminComponent } from './Components/companies-admin/companies-admin.component';
import { CompaniesAddComponent } from './Components/companies-add/companies-add.component';
import { CompaniesEditComponent } from './Components/companies-edit/companies-edit.component';
import { CompaniesStockExchangeComponent } from './Components/companies-stock-exchange/companies-stock-exchange.component';
import { StockExchangeAdminComponent } from './Components/stock-exchange-admin/stock-exchange-admin.component';
import { StockExchangeAddComponent } from './Components/stock-exchange-add/stock-exchange-add.component';
import { StockExchangeEditComponent } from './Components/stock-exchange-edit/stock-exchange-edit.component';
import { IpoAdminComponent } from './Components/ipo-admin/ipo-admin.component';
import { IpoAddComponent } from './Components/ipo-add/ipo-add.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    TempComponent,
    TopBarComponent,
    Temp2Component,
    ExcelImportComponent,
    ManageCompaniesComponent,
    CompaniesAdminComponent,
    CompaniesAddComponent,
    CompaniesEditComponent,
    CompaniesStockExchangeComponent,
    StockExchangeAdminComponent,
    StockExchangeAddComponent,
    StockExchangeEditComponent,
    IpoAdminComponent,
    IpoAddComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
