import { Component, OnInit } from '@angular/core';
import { PageService } from '../../Service/page-service.service';

@Component({
  selector: 'app-manage-companies',
  templateUrl: './manage-companies.component.html',
  styleUrls: ['./manage-companies.component.css']
})
export class ManageCompaniesComponent implements OnInit {

  constructor(private pageService:PageService) { }

  ngOnInit(): void {
  }

}
