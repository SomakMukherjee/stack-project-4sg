import { Component, OnInit } from '@angular/core';
import { Company, Ipo, StockExchange } from '../../Models/Company';
import { PageService } from '../../Service/page-service.service';
import { IntercomponentService } from "../../Service/intercomponent.service";

@Component({
  selector: 'app-ipo-add',
  templateUrl: './ipo-add.component.html',
  styleUrls: ['./ipo-add.component.css']
})
export class IpoAddComponent implements OnInit {

  ipo:Ipo={
            ipoId: "",
            companyName: "",
            stockExchange: "",
            pricePerShare: 0,
            noOfShares: 0,
            openingDate: "",
            openingTime: "",
            remarks: "",
          };
  companyStockExchanges:String[];
  companies:Company[];
  stockExchanges:StockExchange[];
  stockExchangesSelection:StockExchange[];

  ses:string[];
  ipoStatus:string="";
  constructor(private pageService: PageService, private intCom: IntercomponentService) { }

  ngOnInit(): void {
  this.pageService.getCompanies().subscribe(data=>{
      //console.log(data);
      this.companies=data;
    });

  this.pageService.getStockExchanges().subscribe(data =>{
      //console.log(data);
      this.stockExchanges = data;
    });
  }


  onSelectCompany(){
  this.stockExchangesSelection=[];
  for (let i of this.stockExchanges){
      this.stockExchangesSelection.push(i);
    }

  }

   addIpo(e){
      this.pageService.addIpo(this.ipo).subscribe(data=>{

        console.log(data);
        this.ipo=data;
        //console.log("IPO Addition Successful");
        this.ipoStatus="Ipo Addition Successful";
      }
      ,error=>{
          this.ipoStatus="Ipo wiith same name already exists. Try again.";
          //console.log(this.ipoStatus);
      }
    );
  }
}
