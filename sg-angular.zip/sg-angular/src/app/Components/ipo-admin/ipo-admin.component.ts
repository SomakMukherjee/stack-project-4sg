import { Component, OnInit } from '@angular/core';
import { Company, Ipo } from '../../Models/Company';
import { PageService } from '../../Service/page-service.service';
import { IntercomponentService } from "../../Service/intercomponent.service";

@Component({
  selector: 'app-ipo-admin',
  templateUrl: './ipo-admin.component.html',
  styleUrls: ['./ipo-admin.component.css']
})
export class IpoAdminComponent implements OnInit {

  selectedCompany:string;
  companies : Company[];
  ipos:Ipo[];
  ipoStatus:string="";
  constructor(private pageService: PageService, private intCom: IntercomponentService) { }

  ngOnInit(): void {
    console.log('init...Stock Exchanges Admin');
    this.pageService.getCompanies().subscribe(data=>{
      //console.log(data);
      this.companies=data;
    })
  }

  loadIpos(){
    this.pageService.getIpos(this.selectedCompany).subscribe(data=>{
      //console.log(data);
      this.ipos=data;
      this.ipoStatus="";
    },
    error=>{
      this.ipos=[];
      this.ipoStatus="No IPOs found for Company.";
    });
  }

  editIpo(ipoId:string){
    this.intCom.changeIpoId(ipoId);
  }

}
