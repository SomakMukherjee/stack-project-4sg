import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IpoAdminComponent } from './ipo-admin.component';

describe('IpoAdminComponent', () => {
  let component: IpoAdminComponent;
  let fixture: ComponentFixture<IpoAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IpoAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IpoAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
