import { Component, OnInit } from '@angular/core';
import { IntercomponentService } from "../../Service/intercomponent.service";

@Component({
  selector: 'app-top-bar',
  templateUrl: './top-bar.component.html',
  styleUrls: ['./top-bar.component.css']
})
export class TopBarComponent implements OnInit {

  message:string="";
  userDetails: string="";
  constructor(private intCom: IntercomponentService) { }

  ngOnInit(): void {
    this.intCom.currentMessage.subscribe(message => this.message = message);
    this.intCom.currentId.subscribe(userDetails => this.userDetails = userDetails);
  }

  logout(): void{
    this.intCom.changeMessage("Not Logged In");
    this.intCom.changeId("");
   }
}
