import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompaniesStockExchangeComponent } from './companies-stock-exchange.component';

describe('CompaniesStockExchangeComponent', () => {
  let component: CompaniesStockExchangeComponent;
  let fixture: ComponentFixture<CompaniesStockExchangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompaniesStockExchangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompaniesStockExchangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
