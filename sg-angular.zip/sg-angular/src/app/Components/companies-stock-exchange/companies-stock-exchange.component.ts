import { Component, OnInit } from '@angular/core';
import { IntercomponentService } from "../../Service/intercomponent.service";
import { PageService } from '../../Service/page-service.service';
import { Company } from '../../Models/Company';

@Component({
  selector: 'app-companies-stock-exchange',
  templateUrl: './companies-stock-exchange.component.html',
  styleUrls: ['./companies-stock-exchange.component.css']
})
export class CompaniesStockExchangeComponent implements OnInit {

  companyId : string = "";
  stockExchanges: string[];
  companyCodes: string[];
  statusMessage: string ="";
  newStockExchange: string="";
  newCompanyCode: string="";
  company : Company= {
                      companyId:"",
                      companyName:"",
                      ceo:"",
                      boardOfDirectors:"",
                      stockExchanges:[],
                      sector:"",
                      description:"",
                      codeInStockExchange:[]
                    };
  constructor(private pageService: PageService, private intCom: IntercomponentService) { }

  ngOnInit(): void {
    this.intCom.currentCompanyId.subscribe(companyId => this.companyId = companyId);
    this.pageService.getCompanyById(this.companyId).subscribe(company =>
      {
        this.company=company;
      }
    );
    this.pageService.getStockExchanges().subscribe(data =>{
      //console.log(data);
      this.stockExchanges = data;
    });
  }

  getStockCodes(){
    this.pageService.getCompanyCodes(this.newStockExchange).subscribe(data =>{
      //console.log(data);
      this.companyCodes = data;
    });
  }

  addStockExchangeToCompany(e){
    if(this.companyCodes.includes(this.newCompanyCode)){
      this.statusMessage="Company Code already in use";
      return;
    }
    if(this.newCompanyCode==""){
      this.statusMessage="Please enter a company code for this stock exchange";
      return;
    }
    if(this.company.stockExchanges.includes(this.newStockExchange)){
      this.statusMessage="Company already in this Stock Exchange";
      return;
    }
    this.statusMessage="ok";
    console.log("OK");
    this.pageService.addStockExchange(this.newStockExchange,this.newCompanyCode,this.company.companyName).subscribe(data =>{
       //console.log(data);
       this.company=data;
     });
  }

  deleteSE(stockExchange){
    console.log(stockExchange);
    this.pageService.deleteStockExchangeFromCompany(this.company.companyName,stockExchange).subscribe(data =>{
      //console.log(data);
      this.company=data;
    });
  }

}
