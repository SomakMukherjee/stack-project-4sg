import { Component, OnInit } from '@angular/core';
import { PageService } from '../../Service/page-service.service';
import { Company, Sector } from '../../Models/Company';
import { IntercomponentService } from "../../Service/intercomponent.service";

@Component({
  selector: 'app-companies-edit',
  templateUrl: './companies-edit.component.html',
  styleUrls: ['./companies-edit.component.css']
})
export class CompaniesEditComponent implements OnInit {

  deleted: boolean;
  companyE : Company = {
                         companyId:"",
                         companyName:"",
                         ceo:"",
                         boardOfDirectors:"",
                         stockExchanges:[],
                         sector:"",
                         description:"",
                         codeInStockExchange:[]
                       };
  sectors : Sector[];
  companyAdditionStatus: String = "";

  constructor(private pageService: PageService, private intCom: IntercomponentService) { }

  ngOnInit(): void {
    this.deleted=false;
    this.intCom.currentCompanyId.subscribe(companyId => this.companyE.companyId = companyId);
    this.pageService.getCompanyById(this.companyE.companyId).subscribe(company =>
      {
        this.companyE=company;
        //console.log(this.companyE);
      }
    );
    this.pageService.getSectors().subscribe(data =>{
      //console.log(data);
      this.sectors = data;
    });
  }

  updateCompany(e){
     this.pageService.updateCompany(this.companyE).subscribe(data=>{
          //console.log(data);
          this.companyE=data;
          //console.log("Company Update Successful");
          this.companyAdditionStatus="Company Update Successful";
        }
        ,error=>{
          console.log(error);
          if(error.error.companyName=="Company with same name already exists"){
            this.companyAdditionStatus="Company with Same Name already exists";
            console.log(this.companyAdditionStatus);
          }
          else{
          //console.log("companyError");
            this.companyAdditionStatus="Company Not Found";
            console.log(this.companyAdditionStatus);
            }
        }
      );
  }
  deleteCompany(companyId: string){
      console.log(companyId);
      this.intCom.changeCompanyId("");
      this.pageService.deleteCompany(companyId).subscribe(data=>{
        console.log(data);
      });
      this.deleted=true;
      }
}
