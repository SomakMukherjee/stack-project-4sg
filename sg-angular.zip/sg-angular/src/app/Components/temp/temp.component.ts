import { Component, OnInit } from '@angular/core';
import { IntercomponentService } from "../../Service/intercomponent.service";

@Component({
  selector: 'app-temp',
  templateUrl: './temp.component.html',
  styleUrls: ['./temp.component.css']
})
export class TempComponent implements OnInit {

  message:string="";
  constructor(private intCom: IntercomponentService) { }

  ngOnInit(): void {
   this.intCom.currentMessage.subscribe(message => this.message = message);
  }

}
