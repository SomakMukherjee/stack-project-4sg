import { Component, OnInit } from '@angular/core';
import { Company } from '../../Models/Company';
import { PageService } from '../../Service/page-service.service';
import { IntercomponentService } from "../../Service/intercomponent.service";

@Component({
  selector: 'app-companies-admin',
  templateUrl: './companies-admin.component.html',
  styleUrls: ['./companies-admin.component.css']
})
export class CompaniesAdminComponent implements OnInit {

  companies: Company[];

  constructor(private pageService: PageService, private intCom: IntercomponentService) { }

  ngOnInit(): void {

    console.log('init...companies Admin');
    this.pageService.getCompanies().subscribe(data=>{
      //console.log(data);
      this.companies=data;
    });
  }

  loadCompanies(){
    this.pageService.getCompanies().subscribe(data=>{
      //console.log(data);
      this.companies=data;
    });
  }
  addCompany(company: Company){
    this.companies.push(company);
  }

  editCompany(companyId: string){
    //console.log(companyId);
    this.intCom.changeCompanyId(companyId);
  }
}
