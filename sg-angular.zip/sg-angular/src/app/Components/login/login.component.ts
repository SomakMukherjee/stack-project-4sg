import { Component, OnInit } from '@angular/core';
import {UserLogin,UserSignUp,UserResponse} from '../../Models/UserLogin';
import { PageService } from '../../Service/page-service.service';
import { IntercomponentService } from "../../Service/intercomponent.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  message:string="";

  userL : UserLogin = {
    name:"",
    password:"",
    userType:false
  };

  userS : UserSignUp = {
      name:"",
      password:"",
      userType:false,
      email:"",
      mobileNo:""
    };

  userR : UserResponse = {
       userId:"",
       name:"",
       //password:"",
       userType:false,
       email:"",
       mobileNo:""
  };

  showLogin: boolean = false;
  showSignUp:boolean = false;
  enableAdd:boolean = false;
  errorMessage:string = ""
  constructor(private pageService: PageService, private intCom: IntercomponentService) { }

  ngOnInit(): void {
    this.intCom.currentMessage.subscribe(message => this.message = message);
  }

  onShowLogin():void{
    this.showLogin=true;
    this.showSignUp=false;
    console.log(this.showLogin+" "+this.showSignUp);
    //this.pageService.getUsers().subscribe(data=>console.log(data));
  }

  onShowSignUp():void{
      this.showLogin=false;
      this.showSignUp=true;
      //console.log(this.showLogin+" "+this.showSignUp);
    }

  onSubmit(e,submitType:string): void{
    //console.log(submitType);
    if(submitType=="Login"){

      //console.log("Logging "+this.userL.name+" in.");
      //if(this.userL.userType){console.log("As Admin.")}

      this.pageService.login(this.userL).subscribe(data=>{
        //console.log(data);
        this.userR=data;
        /*if(this.userR==null){
          this.errorMessage="Login Fail. Check Name or Password";
        }
        else if(this.userR.name=="Admin Privileges absent"){
          this.errorMessage="Login Fail. No Admin privileges";
        }
        else{*/
          //console.log("Login Success");
          this.errorMessage="";
          this.intCom.changeMessage("Logged In");
          this.intCom.changeId(this.userR.userId);
        },error=>{
        if(error.status==404){
          this.errorMessage="Login Fail. Check Name or Password";
        }
        else if(error.error.name=="Admin Privileges absent"){
          this.errorMessage="Login Fail. No Admin privileges";
        }
      });
    }else{
      //console.log("Sign up with "+this.userS.password+" as password.");

      //if(this.userS.userType){
        //console.log("As Admin.");
      //}
      this.pageService.addUser(this.userS).subscribe(data=>{
        //console.log(data);
        this.userR=data;
        //console.log("SignUp Success");
        this.errorMessage="";
        this.intCom.changeMessage("Logged In");
        this.intCom.changeId(this.userR.userId);
      },error =>{
          //console.log(error.error.name);
          //console.log("blackFlaggon");
          if(error.error.name=="User with same Name already exists"){
            this.errorMessage="SignUp Fail. User with same Name exists";
            //console.log(this.errorMessage);
          }
          else if(error.error.name=="User with same email-Id already exists"){
            this.errorMessage="SignUp Fail. Email in use";
            //console.log(this.errorMessage);
          }
        }
      );
    }
  }
}
