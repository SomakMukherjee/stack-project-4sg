import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StockExchangeAdminComponent } from './stock-exchange-admin.component';

describe('StockExchangeAdminComponent', () => {
  let component: StockExchangeAdminComponent;
  let fixture: ComponentFixture<StockExchangeAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StockExchangeAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StockExchangeAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
