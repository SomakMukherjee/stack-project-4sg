import { Component, OnInit } from '@angular/core';
import { StockExchange } from '../../Models/Company';
import { PageService } from '../../Service/page-service.service';
import { IntercomponentService } from "../../Service/intercomponent.service";

@Component({
  selector: 'app-stock-exchange-admin',
  templateUrl: './stock-exchange-admin.component.html',
  styleUrls: ['./stock-exchange-admin.component.css']
})
export class StockExchangeAdminComponent implements OnInit {

  stockExchanges:StockExchange[];
  constructor(private pageService: PageService, private intCom: IntercomponentService) { }

  ngOnInit(): void {
    //console.log('init...Stock Exchanges Admin');
    this.pageService.getStockExchanges().subscribe(data=>{
      //console.log(data);
      this.stockExchanges=data;
    });
  }

  editSE(seId:string){
    this.intCom.changeStockExchangeId(seId);
  }
}

