import { Component, OnInit } from '@angular/core';
import { StockExchange } from '../../Models/Company';
import { PageService } from '../../Service/page-service.service';
@Component({
  selector: 'app-stock-exchange-add',
  templateUrl: './stock-exchange-add.component.html',
  styleUrls: ['./stock-exchange-add.component.css']
})
export class StockExchangeAddComponent implements OnInit {

  stockExchanges : StockExchange[];
  se:StockExchange = {
    id:"",
    stockExchange:"",
    brief:"",
    contactAddress:"",
    remarks:""
  }
  stockExchangeAdditionStatus:string="";
  constructor(private pageService: PageService) { }

  ngOnInit(): void {
    console.log('init...stock Exchanges Add');
    this.pageService.getStockExchanges().subscribe(data =>{
          //console.log(data);
          this.stockExchanges = data;
        });
  }

  addStockExchange(e){
    console.log(this.se);
    this.pageService.createNewStockExchange(this.se).subscribe(data =>{
          //console.log(data);
          this.se = data;
          this.stockExchangeAdditionStatus="Stock Exchange added";
        },
        error=>{
          //console.log(error);
          if(error.error.brief=="Stock Exchange with similar name already exists"){
            //console.log("Stock Exchange with similar name already exists");
            this.stockExchangeAdditionStatus="Stock Exchange with similar name already exists";
          }
        });
  }

}
