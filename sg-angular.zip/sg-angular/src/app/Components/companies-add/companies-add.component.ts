import { Component, OnInit } from '@angular/core';
import { PageService } from '../../Service/page-service.service';
import { Company, Sector } from '../../Models/Company';

@Component({
  selector: 'app-companies-add',
  templateUrl: './companies-add.component.html',
  styleUrls: ['./companies-add.component.css']
})
export class CompaniesAddComponent implements OnInit {

  companyC: Company = {
    companyId:"",
    companyName:"",
    ceo:"",
    boardOfDirectors:"",
    stockExchanges:[],
    sector:"",
    description:"",
    codeInStockExchange:[]
  };
  companyAdditionStatus: String = "";
  sectors : Sector[];
  constructor(private pageService: PageService) { }

  ngOnInit(): void {
    console.log('init...companies Add');
    this.pageService.getSectors().subscribe(data =>{
          //console.log(data);
          this.sectors = data;
        });
  }

  addCompany(e){
    this.pageService.addCompany(this.companyC).subscribe(data=>{
      console.log(data);
      this.companyC=data;
      //console.log("Company Addition Successful");
      this.companyAdditionStatus="Company Addition Successful";
    }
    ,error=>{
        console.log(error.error.companyName);
        console.log("companyError");
        if(error.error.companyName=="Company with same name already exists. Try again."){
          this.companyAdditionStatus="Company with same name already exists. Try again.";
          //console.log(this.companyAdditionStatus);
        }
      }
    );
  }
}
