import { Component, OnInit } from '@angular/core';
import { IntercomponentService } from "../../Service/intercomponent.service";

@Component({
  selector: 'app-temp2',
  templateUrl: './temp2.component.html',
  styleUrls: ['./temp2.component.css']
})
export class Temp2Component implements OnInit {

  message:string="";
  constructor(private intCom: IntercomponentService) { }

  ngOnInit(): void {
   this.intCom.currentMessage.subscribe(message => this.message = message);
  }

}
