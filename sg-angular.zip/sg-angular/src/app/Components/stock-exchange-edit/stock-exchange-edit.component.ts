import { Component, OnInit } from '@angular/core';
import { IntercomponentService } from "../../Service/intercomponent.service";
import { PageService } from '../../Service/page-service.service';
import { StockExchange } from '../../Models/Company';

@Component({
  selector: 'app-stock-exchange-edit',
  templateUrl: './stock-exchange-edit.component.html',
  styleUrls: ['./stock-exchange-edit.component.css']
})
export class StockExchangeEditComponent implements OnInit {

  deleted:boolean=false;
  se:StockExchange = {
    id:"",
    stockExchange:"",
    brief:"",
    contactAddress:"",
    remarks:""
  }
  stockExchangeAdditionStatus:string="";
  constructor(private pageService: PageService, private intCom: IntercomponentService) {

   }

  ngOnInit(): void {
    this.deleted=false;
    this.intCom.currentStockExchangeId.subscribe(data => this.se.id = data);
    this.pageService.getStockExchangeById(this.se.id).subscribe(se =>
          {
            this.se=se;
            //console.log(this.companyE);
          }
        );
  }

  updateStockExchange(e){
       this.pageService.updateStockExchange(this.se).subscribe(data=>{
            this.se=data;
            this.stockExchangeAdditionStatus="Stock Exchange Update Successful";
          }
          ,error=>{
            console.log(error);
            if(error.error.companyName=="Stock Exchange with same name already exists"){
              this.stockExchangeAdditionStatus="Stock Exchange with Same Name already exists";
              //console.log(this.stockExchangeAdditionStatus);
            }
            else{
              this.stockExchangeAdditionStatus="Stock Exchange Not Found.";
              //console.log(this.stockExchangeAdditionStatus);
              }
          }
        );
    }
}
