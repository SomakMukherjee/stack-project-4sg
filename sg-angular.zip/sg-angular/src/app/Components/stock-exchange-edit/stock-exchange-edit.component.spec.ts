import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StockExchangeEditComponent } from './stock-exchange-edit.component';

describe('StockExchangeEditComponent', () => {
  let component: StockExchangeEditComponent;
  let fixture: ComponentFixture<StockExchangeEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StockExchangeEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StockExchangeEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
