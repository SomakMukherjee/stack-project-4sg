import { Component } from '@angular/core';
import { IntercomponentService } from "./Service/intercomponent.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'StockChartPage';
  message:string="";
  userId:string="";
  constructor(private intCom: IntercomponentService) { }
  ngOnInit(): void {
      this.intCom.currentMessage.subscribe(message => this.message = message);
      this.intCom.currentId.subscribe(userId => this.userId = userId);
    }
}
