export interface UserLogin{
  name : string,
  password: string,
  userType: boolean
}

export interface UserSignUp{
  name : string,
  password: string,
  userType: boolean,
  email : string,
  mobileNo: string
}
export interface UserResponse{
  userId : string,
  name : string,
  userType: boolean,
  email : string,
  mobileNo: string
}
