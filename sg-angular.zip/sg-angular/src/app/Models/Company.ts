export interface Company{
 companyId: string,
 companyName: string,
 ceo: string,
 boardOfDirectors: string,
 stockExchanges: Array<string>,
 sector: string,
 description: string,
 codeInStockExchange: Array<string>
}

export interface Sector{
  id: string,
  sectorName: string,
  brief: string
}

export interface StockExchange{
  id: string,
  stockExchange: string,
  brief: string,
  contactAddress: string,
  remarks: string
}

export interface Ipo{
  ipoId: string,
  companyName: string,
  stockExchange: string,
  pricePerShare: number,
  noOfShares: number,
  openingDate: string,
  openingTime: string,
  remarks: string,
}
